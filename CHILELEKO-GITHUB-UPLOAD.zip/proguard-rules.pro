# Add app-specific ProGuard/R8 keep rules here when release minification is enabled.
