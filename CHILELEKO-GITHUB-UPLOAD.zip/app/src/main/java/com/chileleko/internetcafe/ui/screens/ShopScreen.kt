package com.chileleko.internetcafe.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chileleko.internetcafe.data.CafeRepository
import com.chileleko.internetcafe.model.ShopProduct
import com.chileleko.internetcafe.ui.components.PaymentBottomSheet
import com.chileleko.internetcafe.ui.theme.*

@Composable
fun ShopScreen() {
    val products = CafeRepository.products
    var selectedProduct by remember { mutableStateOf<ShopProduct?>(null) }
    var orderNotification by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Chileleko Tech & Stationery Shop",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Slate100
                )
                Text(
                    text = "Genuine storage, accessories, and copy paper with instant counter pickup",
                    fontSize = 11.sp,
                    color = Slate400
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 160.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(products) { prod ->
                ShopItemCard(
                    product = prod,
                    onBuy = { selectedProduct = prod }
                )
            }
        }
    }

    if (selectedProduct != null) {
        val prod = selectedProduct!!
        PaymentBottomSheet(
            title = "Shop: ${prod.name}",
            amountZMW = prod.sellingPrice,
            itemType = "shop_sale",
            itemId = prod.id,
            onDismiss = { selectedProduct = null },
            onSuccess = { ref ->
                selectedProduct = null
                // Decrement stock
                if (prod.stockQuantity > 0) {
                    prod.stockQuantity -= 1
                    prod.unitsSold += 1
                }
                orderNotification = "Order submitted (Ref: $ref). Staff will verify payment before collection."
            }
        )
    }

    if (orderNotification != null) {
        Snackbar(
            modifier = Modifier.padding(16.dp),
            action = {
                TextButton(onClick = { orderNotification = null }) {
                    Text("OK", color = Amber400)
                }
            },
            containerColor = Slate900,
            contentColor = Slate100
        ) {
            Text(orderNotification!!, fontSize = 12.sp)
        }
    }
}

@Composable
fun ShopItemCard(
    product: ShopProduct,
    onBuy: () -> Unit
) {
    val inStock = product.stockQuantity > 0
    val profit = product.sellingPrice - product.buyingCost

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, Slate800, RoundedCornerShape(12.dp)),
        color = Slate900
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Category & Stock Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = product.category.uppercase(),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = Amber400
                )
                Surface(
                    color = if (inStock) Slate800 else Red950,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = if (inStock) "${product.stockQuantity} in stock" else "Out of stock",
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp),
                        fontSize = 9.sp,
                        color = if (inStock) Slate300 else Red400,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = product.name,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Slate100,
                maxLines = 2,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = product.description,
                fontSize = 11.sp,
                color = Slate400,
                maxLines = 2,
                lineHeight = 14.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "K${String.format("%.0f", product.sellingPrice)}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber400
                    )
                    Text(
                        text = "Margin: +K${String.format("%.0f", profit)}",
                        fontSize = 9.sp,
                        color = Emerald400
                    )
                }

                Button(
                    onClick = onBuy,
                    enabled = inStock,
                    colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = Slate950),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Buy", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
