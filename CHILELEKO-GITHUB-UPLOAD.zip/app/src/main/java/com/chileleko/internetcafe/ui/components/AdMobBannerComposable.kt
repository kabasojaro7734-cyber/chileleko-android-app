package com.chileleko.internetcafe.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.chileleko.internetcafe.data.CafeRepository
import com.chileleko.internetcafe.model.MembershipTier
import com.chileleko.internetcafe.ui.theme.Amber400
import com.chileleko.internetcafe.ui.theme.Slate800
import com.chileleko.internetcafe.ui.theme.Slate900
import com.chileleko.internetcafe.ui.theme.Slate400
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView

/**
 * Google AdMob Banner Composable for Chileleko Internet Cafe.
 * Automatically respects Premium VIP membership (100% ad-free).
 * Uses Google AdMob sample test unit IDs during development.
 */
@Composable
fun AdMobBannerComposable(
    modifier: Modifier = Modifier
) {
    val currentTier = CafeRepository.currentMembership.value

    // Premium VIP members get completely ad-free experience
    if (currentTier == MembershipTier.PREMIUM) {
        return
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Slate900)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.padding(bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SPONSORED ADVERTISEMENT",
                color = Slate400,
                fontSize = 9.sp,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "· Google AdMob Test",
                color = Amber400,
                fontSize = 9.sp
            )
        }

        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            factory = { context ->
                AdView(context).apply {
                    setAdSize(AdSize.BANNER)
                    // Sample AdMob Banner Ad Unit ID
                    adUnitId = "ca-app-pub-3940256099942544/6300978111"
                    loadAd(AdRequest.Builder().build())
                }
            }
        )
    }
}
