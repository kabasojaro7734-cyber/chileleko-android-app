package com.chileleko.internetcafe.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chileleko.internetcafe.data.CafeRepository
import com.chileleko.internetcafe.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentBottomSheet(
    title: String,
    amountZMW: Double,
    itemType: String,
    itemId: String,
    onDismiss: () -> Unit,
    onSuccess: (reference: String) -> Unit
) {
    var selectedMethod by remember { mutableStateOf("mtn_momo") }
    var phoneNumber by remember { mutableStateOf("") }
    val receivingNumber = if (selectedMethod == "mtn_momo") "0974820180" else "0765601014"
    var isProcessing by remember { mutableStateOf(false) }
    var completedRef by remember { mutableStateOf<String?>(null) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Slate900,
        contentColor = Slate100,
        dragHandle = { BottomSheetDefaults.DragHandle(color = Slate700) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .navigationBarsPadding()
        ) {
            if (completedRef != null) {
                // Success state
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success",
                        tint = Emerald400,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Payment Submitted for Verification",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate100
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Transaction Reference: ${completedRef}",
                        fontSize = 14.sp,
                        color = Amber400,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Your payment request has been recorded. Chileleko staff must confirm the payment before your item or service is released.",
                        fontSize = 12.sp,
                        color = Slate400,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = {
                            onSuccess(completedRef!!)
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = Slate950),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Close", fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                // Payment Form
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Checkout & Payment",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Slate100
                        )
                        Text(
                            text = title,
                            fontSize = 13.sp,
                            color = Slate400,
                            maxLines = 1
                        )
                    }
                    Surface(
                        color = Amber950,
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Amber500)
                    ) {
                        Text(
                            text = "K${String.format("%.2f", amountZMW)}",
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            color = Amber300,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Text(
                    text = "Select Payment Channel (Zambia)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Slate300
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Method 1: MTN MoMo
                PaymentMethodOption(
                    title = "MTN Mobile Money",
                    subtitle = "Send payment to Chileleko MTN number 0974820180",
                    badge = "Instant",
                    badgeColor = Emerald400,
                    isSelected = selectedMethod == "mtn_momo",
                    onClick = { selectedMethod = "mtn_momo" }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Method 2: Airtel Money
                PaymentMethodOption(
                    title = "Airtel Money Zambia",
                    subtitle = "Send payment to Chileleko Airtel number 0765601014",
                    badge = "Instant",
                    badgeColor = Emerald400,
                    isSelected = selectedMethod == "airtel_money",
                    onClick = { selectedMethod = "airtel_money" }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Method 3: Cafe Cash
                PaymentMethodOption(
                    title = "Cash at Chileleko Counter",
                    subtitle = "Pay directly at the Chileleko Internet Cafe counter",
                    badge = "Desk Verification",
                    badgeColor = Amber400,
                    isSelected = selectedMethod == "cafe_cash",
                    onClick = { selectedMethod = "cafe_cash" }
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (selectedMethod != "cafe_cash") {
                    Text(
                        text = "Your Mobile Number (for payment follow-up)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Slate300
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = { phoneNumber = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Enter your number", color = Slate400) },
                        leadingIcon = {
                            Icon(Icons.Default.Phone, contentDescription = null, tint = Amber400)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Amber400,
                            unfocusedBorderColor = Slate700,
                            focusedTextColor = Slate100,
                            unfocusedTextColor = Slate100,
                            focusedContainerColor = Slate850,
                            unfocusedContainerColor = Slate850
                        ),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Send the exact amount to the Chileleko number shown below using your mobile money menu. Enter your own number above so staff can identify your payment.",
                        fontSize = 11.sp,
                        color = Slate400
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Slate850,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Amber500)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("SEND PAYMENT TO CHILELEKO", color = Amber400, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(receivingNumber, color = Slate100, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                            Text(if (selectedMethod == "mtn_momo") "MTN Mobile Money" else "Airtel Money", color = Slate300, fontSize = 11.sp)
                            Text("Amount: K${String.format("%.2f", amountZMW)}. Keep your transaction SMS/reference.", color = Slate300, fontSize = 11.sp)
                        }
                    }
                } else {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Slate850,
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate700)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Desk Cash Payment Process",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Amber400
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "A pending transaction voucher will be generated. Hand your cash to the cashier at Cairo Road, who will verify your voucher on the Admin Console.",
                                fontSize = 11.sp,
                                color = Slate300
                            )
                        }
                    }
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMessage!!,
                        color = Red400,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        if (selectedMethod != "cafe_cash" && phoneNumber.trim().length < 9) {
                            errorMessage = "Please enter your mobile number for payment follow-up"
                            return@Button
                        }
                        isProcessing = true
                        errorMessage = null

                        // Execute purchase via repository
                        if (itemType == "document") {
                            val ref = CafeRepository.purchaseDocument(itemId, selectedMethod, phoneNumber)
                            completedRef = ref
                        } else {
                            // Service or Membership or Shop item
                            val ref = "PAY-ZM-${kotlin.random.Random.nextInt(10000, 99999)}"
                            val now = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                            CafeRepository.transactions.add(0, com.chileleko.internetcafe.model.Transaction(
                                id = "tx-${System.currentTimeMillis()}",
                                type = itemType,
                                title = title,
                                grossAmount = amountZMW,
                                costAmount = 0.0,
                                netProfit = amountZMW,
                                paymentMethod = selectedMethod,
                                reference = ref,
                                status = "pending",
                                timestamp = now,
                                customerPhone = phoneNumber
                            ))
                            completedRef = ref
                        }
                        isProcessing = false
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = Slate950),
                    shape = RoundedCornerShape(10.dp),
                    enabled = !isProcessing
                ) {
                    if (isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Slate950, strokeWidth = 2.dp)
                    } else {
                        Text(
                            text = if (selectedMethod == "cafe_cash") "Submit Cash Payment for Verification" else "I've Sent Payment – Submit for Verification",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}

@Composable
fun PaymentMethodOption(
    title: String,
    subtitle: String,
    badge: String,
    badgeColor: Color,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) Amber400 else Slate800,
                shape = RoundedCornerShape(10.dp)
            ),
        color = if (isSelected) Slate800 else Slate850
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate100
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = badgeColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = badge,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = badgeColor,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = Slate400
                )
            }
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(
                    selectedColor = Amber400,
                    unselectedColor = Slate700
                )
            )
        }
    }
}
