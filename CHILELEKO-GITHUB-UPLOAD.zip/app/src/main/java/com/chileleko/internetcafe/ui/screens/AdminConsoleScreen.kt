package com.chileleko.internetcafe.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chileleko.internetcafe.data.CafeRepository
import com.chileleko.internetcafe.model.AdminUser
import com.chileleko.internetcafe.ui.theme.*

@Composable
fun AdminConsoleScreen() {
    var isAuthenticated by remember { mutableStateOf(CafeRepository.isAdminAuthenticated.value) }
    var pinInput by remember { mutableStateOf("") }
    var authError by remember { mutableStateOf<String?>(null) }
    var activeAdminTab by remember { mutableStateOf("revenue") } // revenue, services, shop, admins, payments

    if (!isAuthenticated) {
        // PIN Lock Screen
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Slate950)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = Amber400,
                modifier = Modifier.size(48.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Chileleko Admin Authentication",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Slate100
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Enter your 4-digit administrator security PIN to manage revenue, pricing, and staff accounts.",
                fontSize = 12.sp,
                color = Slate400,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedTextField(
                value = pinInput,
                onValueChange = { if (it.length <= 6) pinInput = it },
                placeholder = { Text("Enter 4-digit PIN (Default: 2026)", color = Slate400) },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Amber400,
                    unfocusedBorderColor = Slate700,
                    focusedTextColor = Slate100,
                    unfocusedTextColor = Slate100,
                    focusedContainerColor = Slate900,
                    unfocusedContainerColor = Slate900
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth(0.85f)
            )

            if (authError != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = authError!!, color = Red400, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    val matching = CafeRepository.adminUsers.find { it.pin == pinInput && it.active }
                    if (matching != null) {
                        CafeRepository.currentAdmin.value = matching
                        CafeRepository.isAdminAuthenticated.value = true
                        isAuthenticated = true
                        authError = null
                    } else {
                        authError = "Invalid administrator PIN. Try master PIN: 2026"
                    }
                },
                modifier = Modifier.fillMaxWidth(0.85f),
                colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = Slate950),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Unlock Admin Console", fontWeight = FontWeight.Bold)
            }
        }
    } else {
        // Authenticated Admin Dashboard
        val currentAdmin = CafeRepository.currentAdmin.value

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Slate950)
        ) {
            // Admin Top Identity Bar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Slate900,
                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = currentAdmin?.fullName ?: "Administrator",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Slate100
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = Amber950,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = (currentAdmin?.role ?: "Admin").replace("_", " ").uppercase(),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Amber400
                                )
                            }
                        }
                        Text(
                            text = currentAdmin?.branchLocation ?: "Cairo Road Main Hub",
                            fontSize = 11.sp,
                            color = Slate400
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            isAuthenticated = false
                            pinInput = ""
                            CafeRepository.isAdminAuthenticated.value = false
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Slate300),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Slate700),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("Lock", fontSize = 11.sp)
                    }
                }
            }

            // Admin Navigation Tabs
            val tabs = listOf(
                "revenue" to "Revenue KPIs",
                "admins" to "Admin Accounts",
                "services" to "Service Prices",
                "shop" to "Shop Inventory",
                "payments" to "Cash Desk Verifications"
            )

            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(tabs) { (id, label) ->
                    val isSelected = activeAdminTab == id
                    FilterChip(
                        selected = isSelected,
                        onClick = { activeAdminTab = id },
                        label = { Text(label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Amber400,
                            selectedLabelColor = Slate950,
                            containerColor = Slate900,
                            labelColor = Slate300
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) Amber400 else Slate800
                        )
                    )
                }
            }

            // Tab Content
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                when (activeAdminTab) {
                    "revenue" -> AdminRevenueSection()
                    "admins" -> AdminAccountsSection()
                    "services" -> AdminServicesSection()
                    "shop" -> AdminShopSection()
                    "payments" -> AdminPaymentsSection()
                }
            }
        }
    }
}

@Composable
fun AdminRevenueSection() {
    val totalRevenue = CafeRepository.calculateTotalGrossRevenue()
    val totalProfit = CafeRepository.calculateTotalNetProfit()
    val shopProfit = CafeRepository.calculateShopNetProfit()
    val transactions = CafeRepository.transactions

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            // Revenue KPI Cards Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    modifier = Modifier.weight(1f),
                    color = Slate900,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("TOTAL REVENUE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Slate400)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("K${String.format("%.2f", totalRevenue)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Slate100)
                        Text("Gross collections", fontSize = 10.sp, color = Slate400)
                    }
                }

                Surface(
                    modifier = Modifier.weight(1f),
                    color = Slate900,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Emerald950)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("ESTIMATED NET PROFIT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Emerald400)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("K${String.format("%.2f", totalProfit)}", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Emerald400)
                        Text("After product costs", fontSize = 10.sp, color = Slate400)
                    }
                }
            }
        }

        item {
            // Breakdown Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Slate900,
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Income Streams Summary", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Amber400)
                    Spacer(modifier = Modifier.height(8.dp))
                    StreamSummaryRow("Document Downloads", "K${String.format("%.0f", transactions.filter { it.type == "document_sale" }.sumOf { it.grossAmount })}")
                    StreamSummaryRow("Bureau Services Charges", "K${String.format("%.0f", transactions.filter { it.type == "service_charge" }.sumOf { it.grossAmount })}")
                    StreamSummaryRow("Membership Subscriptions", "K${String.format("%.0f", transactions.filter { it.type == "membership_sub" }.sumOf { it.grossAmount })}")
                    StreamSummaryRow("Shop Net Profits", "K${String.format("%.0f", shopProfit)}")
                    StreamSummaryRow("Sponsored Ads Income", "K${String.format("%.0f", transactions.filter { it.type == "sponsored_ad" }.sumOf { it.grossAmount })}")
                    StreamSummaryRow("Google AdMob Earnings", "K${String.format("%.2f", CafeRepository.adMobEstimatedEarnings.value)}")
                }
            }
        }

        item {
            Text("Recent Cafe Transactions", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Slate100, modifier = Modifier.padding(top = 4.dp))
        }

        items(transactions) { tx ->
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Slate900,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(tx.title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Slate100)
                        Text("${tx.reference} · ${tx.paymentMethod.replace("_", " ").uppercase()} · ${tx.timestamp}", fontSize = 10.sp, color = Slate400)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("+K${String.format("%.2f", tx.grossAmount)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Amber400)
                        Surface(
                            color = if (tx.status == "verified") Emerald950 else Amber950,
                            shape = RoundedCornerShape(3.dp)
                        ) {
                            Text(
                                text = tx.status.uppercase(),
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (tx.status == "verified") Emerald400 else Amber400,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StreamSummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 12.sp, color = Slate300)
        Text(value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate100)
    }
}

@Composable
fun AdminAccountsSection() {
    val admins = CafeRepository.adminUsers
    var showAddDialog by remember { mutableStateOf(false) }
    var actionMessage by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Administrator Directory", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Slate100)
                Text("${admins.size} authorized administrators & cashiers", fontSize = 11.sp, color = Slate400)
            }

            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = Slate950),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Administrator", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(admins) { admin ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Slate900,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(admin.fullName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Slate100)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(color = Slate800, shape = RoundedCornerShape(4.dp)) {
                                        Text(
                                            text = admin.role.replace("_", " ").uppercase(),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Amber400,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text("${admin.phone} · ${admin.email}", fontSize = 11.sp, color = Slate400)
                                Text("Branch: ${admin.branchLocation}", fontSize = 11.sp, color = Slate300)
                            }

                            if (admin.role != "super_admin") {
                                IconButton(
                                    onClick = {
                                        if (CafeRepository.deleteAdministrator(admin.id)) {
                                            actionMessage = "Administrator removed."
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Red400, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Security PIN: ••••", fontSize = 10.sp, color = Slate400)
                            Text("Last Active: ${admin.lastLoginAt}", fontSize = 10.sp, color = Slate400)
                        }
                    }
                }
            }
        }
    }

    // Add Admin Dialog
    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var role by remember { mutableStateOf("branch_manager") }
        var pin by remember { mutableStateOf("") }
        var branch by remember { mutableStateOf("Cairo Road Main Hub") }
        var formError by remember { mutableStateOf<String?>(null) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Administrator Account", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Slate100) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        placeholder = { Text("Full Name (e.g. Kondwani Banda)", color = Slate400, fontSize = 12.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate100, unfocusedTextColor = Slate100),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        placeholder = { Text("Mobile Phone (+260 97X XXX XXX)", color = Slate400, fontSize = 12.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate100, unfocusedTextColor = Slate100),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { if (it.length <= 4) pin = it },
                        placeholder = { Text("4-Digit Security PIN (e.g. 7744)", color = Slate400, fontSize = 12.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate100, unfocusedTextColor = Slate100),
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = branch,
                        onValueChange = { branch = it },
                        placeholder = { Text("Branch Location (e.g. Cairo Road Hub)", color = Slate400, fontSize = 12.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate100, unfocusedTextColor = Slate100),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (formError != null) {
                        Text(formError!!, color = Red400, fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (name.isBlank() || phone.isBlank() || pin.length < 4) {
                            formError = "Please fill in Name, Phone, and 4-digit PIN"
                            return@Button
                        }
                        val success = CafeRepository.addAdministrator(name, email, phone, role, pin, branch)
                        if (success) {
                            showAddDialog = false
                            actionMessage = "Administrator $name created successfully with 4-digit PIN!"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = Slate950)
                ) {
                    Text("Save Administrator", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = Slate400)
                }
            },
            containerColor = Slate900,
            shape = RoundedCornerShape(12.dp)
        )
    }

    if (actionMessage != null) {
        Snackbar(
            modifier = Modifier.padding(16.dp),
            action = { TextButton(onClick = { actionMessage = null }) { Text("OK", color = Amber400) } },
            containerColor = Slate900,
            contentColor = Slate100
        ) {
            Text(actionMessage!!, fontSize = 12.sp)
        }
    }
}

@Composable
fun AdminServicesSection() {
    val services = CafeRepository.services

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        items(services) { srv ->
            var isEditing by remember { mutableStateOf(false) }
            var priceText by remember { mutableStateOf(srv.price.toInt().toString()) }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Slate900,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(srv.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Slate100)
                        Text("${srv.category} · ${srv.unitLabel}", fontSize = 11.sp, color = Slate400)
                    }

                    if (isEditing) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = priceText,
                                onValueChange = { priceText = it },
                                modifier = Modifier.width(70.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Slate100, unfocusedTextColor = Slate100)
                            )
                            IconButton(
                                onClick = {
                                    val newP = priceText.toDoubleOrNull()
                                    if (newP != null && newP >= 0) {
                                        srv.price = newP
                                    }
                                    isEditing = false
                                }
                            ) {
                                Icon(Icons.Default.Check, contentDescription = "Save", tint = Emerald400)
                            }
                        }
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("K${String.format("%.0f", srv.price)}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Amber400)
                            IconButton(onClick = { isEditing = true }) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Slate400, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminShopSection() {
    val products = CafeRepository.products

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        items(products) { prod ->
            val unitProfit = prod.sellingPrice - prod.buyingCost
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Slate900,
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(prod.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Slate100)
                        Text("Stock: ${prod.stockQuantity}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (prod.stockQuantity > 5) Emerald400 else Amber400)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Cost: K${String.format("%.0f", prod.buyingCost)}  ·  Sell: K${String.format("%.0f", prod.sellingPrice)}", fontSize = 11.sp, color = Slate400)
                        Text("Profit/Unit: +K${String.format("%.0f", unitProfit)}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Emerald400)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminPaymentsSection() {
    val pending = CafeRepository.transactions.filter { it.status == "pending" }

    if (pending.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No pending desk cash verifications right now.", color = Slate400, fontSize = 13.sp)
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(pending) { tx ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Slate900,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Amber500.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(tx.title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Slate100)
                            Text("Ref: ${tx.reference} · Amount: K${String.format("%.2f", tx.grossAmount)}", fontSize = 11.sp, color = Amber400)
                            Text("Customer Phone: ${tx.customerPhone} · ${tx.timestamp}", fontSize = 10.sp, color = Slate400)
                        }

                        Button(
                            onClick = { tx.status = "verified" },
                            colors = ButtonDefaults.buttonColors(containerColor = Emerald500, contentColor = Slate950),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("Verify Cash", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
