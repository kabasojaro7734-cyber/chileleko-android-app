package com.chileleko.internetcafe.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chileleko.internetcafe.data.CafeRepository
import com.chileleko.internetcafe.model.ReferralRecord
import com.chileleko.internetcafe.ui.theme.*

@Composable
fun ReferralsScreen() {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val code = CafeRepository.userReferralCode
    val rule = CafeRepository.referralRule.value
    val records = CafeRepository.referralRecords
    var copyAlert by remember { mutableStateOf<String?>(null) }

    val totalEarned = records.filter { it.status == "credited" }.sumOf { it.rewardEarnedZMW }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Referral Hero Card
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, Amber500.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
            color = Slate900
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Invite Friends & Earn Real MoMo Cash",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Slate100
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Give K${String.format("%.0f", rule.refereeDiscountZMW)} discount to friends, earn K${String.format("%.0f", rule.referrerRewardZMW)} MoMo credit on their first cafe service or download.",
                    fontSize = 12.sp,
                    color = Slate400
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Unique Code Box
                Surface(
                    color = Slate950,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate800),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("YOUR EXCLUSIVE CODE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Slate400, letterSpacing = 1.sp)
                            Text(code, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Amber400)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(code))
                                    copyAlert = "Referral code copied to clipboard!"
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Slate300),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Slate700),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text("Copy", fontSize = 11.sp)
                            }

                            Button(
                                onClick = {
                                    val sendIntent = Intent().apply {
                                        action = Intent.ACTION_SEND
                                        putExtra(Intent.EXTRA_TEXT, "Get K3 discount on exam past papers, CV typing and print services at Chileleko Internet Cafe Lusaka! Use my invite code: $code or visit our Cairo Road main hub.")
                                        type = "text/plain"
                                    }
                                    val shareIntent = Intent.createChooser(sendIntent, "Share Chileleko Cafe Invite")
                                    context.startActivity(shareIntent)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = Slate950),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Share", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Stats row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Total Earned: K${String.format("%.2f", totalEarned)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Emerald400)
                    Text("Active Invites: ${records.size} / ${rule.maxReferralsPerUser}", fontSize = 12.sp, color = Slate400)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Anti-abuse info
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Slate900.copy(alpha = 0.6f),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate850)
        ) {
            Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = Amber400, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Fraud Prevention: Verified by device hardware ID and Zambian phone carrier. Minimum qualifying spend is K${String.format("%.0f", rule.minimumSpendRequirement)}.",
                    fontSize = 11.sp,
                    color = Slate400
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "Your Referral Activity",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Slate100
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(records) { rec ->
                ReferralItemCard(rec)
            }
        }
    }

    if (copyAlert != null) {
        Snackbar(
            modifier = Modifier.padding(16.dp),
            action = {
                TextButton(onClick = { copyAlert = null }) {
                    Text("OK", color = Amber400)
                }
            },
            containerColor = Slate900,
            contentColor = Slate100
        ) {
            Text(copyAlert!!, fontSize = 12.sp)
        }
    }
}

@Composable
fun ReferralItemCard(record: ReferralRecord) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, Slate800, RoundedCornerShape(10.dp)),
        color = Slate900
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(record.refereeName, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Slate100)
                Text("${record.refereePhone} · ${record.createdAt}", fontSize = 11.sp, color = Slate400)
            }

            Column(horizontalAlignment = Alignment.End) {
                Surface(
                    color = when (record.status) {
                        "credited" -> Emerald950
                        "qualified" -> Amber950
                        else -> Slate800
                    },
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = record.status.uppercase(),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (record.status) {
                            "credited" -> Emerald400
                            "qualified" -> Amber400
                            else -> Slate400
                        }
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (record.rewardEarnedZMW > 0) "+K${String.format("%.2f", record.rewardEarnedZMW)}" else "Pending spend",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (record.rewardEarnedZMW > 0) Emerald400 else Slate400
                )
            }
        }
    }
}
