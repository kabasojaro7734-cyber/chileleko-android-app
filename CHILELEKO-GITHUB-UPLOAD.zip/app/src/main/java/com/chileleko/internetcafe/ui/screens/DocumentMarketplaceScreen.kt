package com.chileleko.internetcafe.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chileleko.internetcafe.data.CafeRepository
import com.chileleko.internetcafe.model.DocumentItem
import com.chileleko.internetcafe.model.MembershipTier
import com.chileleko.internetcafe.ui.components.PaymentBottomSheet
import com.chileleko.internetcafe.ui.theme.*

@Composable
fun DocumentMarketplaceScreen(
    onTriggerRewardedAd: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var previewDoc by remember { mutableStateOf<DocumentItem?>(null) }
    var paymentDoc by remember { mutableStateOf<DocumentItem?>(null) }
    var downloadedAlert by remember { mutableStateOf<String?>(null) }

    val categories = listOf("All", "Exams & Education", "Employment & CVs", "Business & Legal", "Government Forms")
    val allDocs = CafeRepository.documents
    val purchasedIds = CafeRepository.purchasedDocumentIds
    val currentTier = CafeRepository.currentMembership.value

    val filteredDocs = allDocs.filter { doc ->
        val matchesCategory = (selectedCategory == "All") || (doc.category == selectedCategory)
        val matchesSearch = doc.title.contains(searchQuery, ignoreCase = true) ||
                doc.description.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
    ) {
        // Search & Filter Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Search past papers, CV packs, PACRA kits...", color = Slate400, fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Amber400) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Amber400,
                    unfocusedBorderColor = Slate800,
                    focusedTextColor = Slate100,
                    unfocusedTextColor = Slate100,
                    focusedContainerColor = Slate900,
                    unfocusedContainerColor = Slate900
                ),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Category Chips Row
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { cat ->
                    val isSelected = cat == selectedCategory
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Amber400,
                            selectedLabelColor = Slate950,
                            containerColor = Slate900,
                            labelColor = Slate300
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = if (isSelected) Amber400 else Slate800
                        )
                    )
                }
            }
        }

        // Document List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(filteredDocs) { doc ->
                val isPurchased = purchasedIds.contains(doc.id) || (currentTier == MembershipTier.PREMIUM)
                val effectivePrice = when (currentTier) {
                    MembershipTier.PREMIUM -> 0.0
                    MembershipTier.STANDARD -> if (doc.price <= 5.0) 0.0 else (doc.price * 0.5)
                    else -> doc.price
                }

                DocumentCard(
                    doc = doc,
                    isPurchased = isPurchased,
                    effectivePrice = effectivePrice,
                    onPreview = { previewDoc = doc },
                    onDownload = {
                        downloadedAlert = "Downloaded: ${doc.title} (${doc.fileFormat}, ${doc.fileSize}). Saved to phone Downloads folder."
                    },
                    onPurchase = { paymentDoc = doc },
                    onAdUnlock = {
                        if (CafeRepository.userRewardTokens.value > 0) {
                            CafeRepository.userRewardTokens.value -= 1
                            CafeRepository.purchasedDocumentIds.add(doc.id)
                            downloadedAlert = "Unlocked using Reward Token! Downloading ${doc.title}."
                        } else {
                            onTriggerRewardedAd()
                        }
                    }
                )
            }
        }
    }

    // Preview Dialog
    if (previewDoc != null) {
        val doc = previewDoc!!
        AlertDialog(
            onDismissRequest = { previewDoc = null },
            title = {
                Text(
                    text = doc.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Slate100
                )
            },
            text = {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${doc.fileFormat} · ${doc.pageCount} Pages", color = Amber400, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text("${doc.downloadsCount} downloads", color = Slate400, fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Document Abstract & Verified Excerpt:",
                        color = Slate300,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Surface(
                        color = Slate850,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = doc.samplePreviewText,
                            modifier = Modifier.padding(10.dp),
                            color = Slate300,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = doc.description,
                        color = Slate400,
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val target = previewDoc
                        previewDoc = null
                        if (target != null && !purchasedIds.contains(target.id)) {
                            paymentDoc = target
                        }
                    }
                ) {
                    Text("Proceed to Download", color = Amber400, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { previewDoc = null }) {
                    Text("Close", color = Slate400)
                }
            },
            containerColor = Slate900,
            shape = RoundedCornerShape(12.dp)
        )
    }

    // Payment Bottom Sheet
    if (paymentDoc != null) {
        val doc = paymentDoc!!
        PaymentBottomSheet(
            title = "Download: ${doc.title}",
            amountZMW = doc.price,
            itemType = "document",
            itemId = doc.id,
            onDismiss = { paymentDoc = null },
            onSuccess = { ref ->
                paymentDoc = null
                downloadedAlert = "Payment submitted (Ref: $ref). Access will be released after staff verify your payment."
            }
        )
    }

    // Download Notification Snackbar
    if (downloadedAlert != null) {
        Snackbar(
            modifier = Modifier.padding(16.dp),
            action = {
                TextButton(onClick = { downloadedAlert = null }) {
                    Text("OK", color = Amber400)
                }
            },
            containerColor = Slate900,
            contentColor = Slate100
        ) {
            Text(downloadedAlert!!, fontSize = 12.sp)
        }
    }
}

@Composable
fun DocumentCard(
    doc: DocumentItem,
    isPurchased: Boolean,
    effectivePrice: Double,
    onPreview: () -> Unit,
    onDownload: () -> Unit,
    onPurchase: () -> Unit,
    onAdUnlock: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, Slate800, RoundedCornerShape(12.dp)),
        color = Slate900
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Category Badge + Price Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = Slate800,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = doc.category.uppercase(),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber400,
                        letterSpacing = 0.5.sp
                    )
                }

                Surface(
                    color = if (doc.price == 0.0 || isPurchased) Emerald950 else Amber950,
                    shape = RoundedCornerShape(6.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (doc.price == 0.0 || isPurchased) Emerald500 else Amber500
                    )
                ) {
                    Text(
                        text = if (isPurchased) "OWNED / UNLOCKED" else if (doc.price == 0.0) "FREE" else "K${String.format("%.0f", effectivePrice)}",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPurchased || doc.price == 0.0) Emerald400 else Amber300
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Title
            Text(
                text = doc.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Slate100,
                lineHeight = 18.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Meta Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("${doc.fileFormat} · ${doc.fileSize}", fontSize = 11.sp, color = Slate400)
                Text("·", fontSize = 11.sp, color = Slate700)
                Text("${doc.pageCount} Pages", fontSize = 11.sp, color = Slate400)
                Text("·", fontSize = 11.sp, color = Slate700)
                Text("${doc.downloadsCount} Downloads", fontSize = 11.sp, color = Slate400)
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Description
            Text(
                text = doc.description,
                fontSize = 12.sp,
                color = Slate300,
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onPreview,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Slate300),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate700),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Sample", fontSize = 12.sp)
                }

                if (isPurchased || doc.price == 0.0) {
                    Button(
                        onClick = onDownload,
                        modifier = Modifier.weight(1.5f),
                        colors = ButtonDefaults.buttonColors(containerColor = Emerald500, contentColor = Slate950),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Download PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = onPurchase,
                        modifier = Modifier.weight(1.5f),
                        colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = Slate950),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(vertical = 6.dp)
                    ) {
                        Text("Pay K${String.format("%.0f", effectivePrice)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
