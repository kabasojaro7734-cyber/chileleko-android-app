package com.chileleko.internetcafe.model

enum class MembershipTier(val label: String) {
    FREE("Free"),
    STANDARD("Standard"),
    PREMIUM("Premium VIP")
}

enum class BillingCycle(val label: String) {
    MONTHLY("Monthly"),
    YEARLY("Yearly")
}

data class DocumentItem(
    val id: String,
    val title: String,
    val category: String,
    val price: Double,
    val tierLabel: String,
    val description: String,
    val fileFormat: String,
    val fileSize: String,
    val pageCount: Int,
    val downloadsCount: Int,
    val samplePreviewText: String
)

data class MembershipPlan(
    val id: MembershipTier,
    val name: String,
    val monthlyPrice: Double,
    val yearlyPrice: Double,
    val tagline: String,
    val features: List<String>,
    val adPolicy: String,
    val serviceDiscountPercent: Int,
    val freeDownloadsNote: String
)

data class CafeService(
    val id: String,
    val name: String,
    val category: String,
    var price: Double,
    val unitLabel: String,
    val description: String,
    val turnaroundTime: String,
    var active: Boolean = true
)

data class ServiceOrder(
    val id: String,
    val serviceId: String,
    val serviceName: String,
    val customerName: String,
    val customerPhone: String,
    val quantity: Int,
    val totalAmount: Double,
    val notes: String,
    val status: String,
    val paymentMethod: String,
    val paymentReference: String,
    val createdAt: String
)

data class ShopProduct(
    val id: String,
    val name: String,
    val category: String,
    var sellingPrice: Double,
    var buyingCost: Double,
    var stockQuantity: Int,
    val reorderLevel: Int,
    val description: String,
    var unitsSold: Int = 0
)

data class SponsoredAd(
    val id: String,
    val businessName: String,
    val category: String,
    val contactPhone: String,
    val whatsappNumber: String,
    val headline: String,
    val tagline: String,
    var monthlyFeeZMW: Double,
    val startDate: String,
    val expiryDate: String,
    var impressionsCount: Int,
    var clicksCount: Int,
    var status: String
)

data class AdminUser(
    val id: String,
    val fullName: String,
    val email: String,
    val phone: String,
    val role: String, // super_admin, branch_manager, cashier, finance_officer
    var pin: String,
    val branchLocation: String,
    var active: Boolean = true,
    val createdAt: String,
    var lastLoginAt: String = "Pending"
)

data class Transaction(
    val id: String,
    val type: String, // document_sale, membership_sub, service_charge, shop_sale, sponsored_ad, admob_payout, referral_expense
    val title: String,
    val grossAmount: Double,
    val costAmount: Double,
    val netProfit: Double,
    val paymentMethod: String, // mtn_momo, airtel_money, cafe_cash, admob_network, system_credit
    val reference: String,
    var status: String, // verified, pending
    val timestamp: String,
    val customerPhone: String = "Counter"
)

data class ReferralRule(
    var referrerRewardZMW: Double = 5.0,
    var refereeDiscountZMW: Double = 3.0,
    var minimumSpendRequirement: Double = 10.0,
    var maxReferralsPerUser: Int = 25
)

data class ReferralRecord(
    val id: String,
    val referrerCode: String,
    val refereePhone: String,
    val refereeName: String,
    val status: String,
    val spentAmount: Double,
    val rewardEarnedZMW: Double,
    val createdAt: String
)
