package com.chileleko.internetcafe.data

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import com.chileleko.internetcafe.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

object CafeRepository {

    // Current Customer Membership & Session
    val currentMembership = mutableStateOf(MembershipTier.FREE)
    val membershipCycle = mutableStateOf(BillingCycle.MONTHLY)
    val userRewardTokens = mutableStateOf(1)
    val purchasedDocumentIds = mutableStateListOf("doc-8") // Free guide owned

    // Documents Catalog
    val documents = mutableStateListOf(
        DocumentItem(
            id = "doc-1",
            title = "ECZ Grade 12 Mathematics Past Papers & Solutions (2020 - 2024)",
            category = "Exams & Education",
            price = 5.0,
            tierLabel = "K5",
            description = "Complete verified examinations question papers for Paper 1 and Paper 2 with step-by-step marking schemes.",
            fileFormat = "PDF",
            fileSize = "4.8 MB",
            pageCount = 68,
            downloadsCount = 142,
            samplePreviewText = "SECTION A [40 Marks]. Answer all questions in this section. 1. Evaluate 3(2x - 5) + 4(x + 2)..."
        ),
        DocumentItem(
            id = "doc-2",
            title = "TEVETA Trade Test General Automotive & Electrical Revision Guide",
            category = "Exams & Education",
            price = 10.0,
            tierLabel = "K10",
            description = "Technical revision question bank and workshop examination checklist approved for TEVETA candidates.",
            fileFormat = "PDF",
            fileSize = "6.2 MB",
            pageCount = 54,
            downloadsCount = 89,
            samplePreviewText = "Module 3: Battery and Starting Circuits. Identify alternator output specifications, diode bridge testing..."
        ),
        DocumentItem(
            id = "doc-3",
            title = "Professional Zambian ATS-Ready CV & Cover Letter Template Pack",
            category = "Employment & CVs",
            price = 10.0,
            tierLabel = "K10",
            description = "Modern, recruiter-tested resume layout optimized for NGOs, banks, and government ministries across Zambia.",
            fileFormat = "DOCX",
            fileSize = "1.4 MB",
            pageCount = 4,
            downloadsCount = 230,
            samplePreviewText = "CURRICULUM VITAE - [Full Name] | NRC: XXXXXX/XX/1 | Lusaka, Zambia | Results-driven administrative officer..."
        ),
        DocumentItem(
            id = "doc-4",
            title = "PACRA Business Registration & Annual Returns Step-by-Step Kit",
            category = "Business & Legal",
            price = 20.0,
            tierLabel = "K20",
            description = "Exhaustive guide to registering a Company or Business Name via the PACRA portal with sample resolution forms.",
            fileFormat = "PDF",
            fileSize = "3.1 MB",
            pageCount = 38,
            downloadsCount = 76,
            samplePreviewText = "Companies Act No. 10 of 2017: Form 2 Application for Incorporation. Step 1: Name Availability Reservation..."
        ),
        DocumentItem(
            id = "doc-5",
            title = "ZRA Tax Clearance (TPIN & Presumptive Tax) Compliance Guide",
            category = "Business & Legal",
            price = 10.0,
            tierLabel = "K10",
            description = "How to obtain a Tax Clearance Certificate (TCC), register for turnover tax, and calculate small business tax.",
            fileFormat = "PDF",
            fileSize = "2.5 MB",
            pageCount = 24,
            downloadsCount = 94,
            samplePreviewText = "Zambia Revenue Authority Portal Guide: Direct Taxes Division. Presumptive tax schedule for passenger transport..."
        ),
        DocumentItem(
            id = "doc-6",
            title = "ECZ Grade 9 Junior Secondary Science & Social Studies Mock Exam",
            category = "Exams & Education",
            price = 2.0,
            tierLabel = "K2",
            description = "Concise quick revision mock test with answer key for Junior Secondary School Leaving Examination.",
            fileFormat = "PDF",
            fileSize = "1.9 MB",
            pageCount = 16,
            downloadsCount = 310,
            samplePreviewText = "Paper 1 Multiple Choice: 1. Photosynthesis occurs primarily in which organelle? A. Mitochondria B. Chloroplast..."
        ),
        DocumentItem(
            id = "doc-7",
            title = "Standard Zambian Residential Tenancy Agreement & Lease Deed",
            category = "Business & Legal",
            price = 20.0,
            tierLabel = "K20",
            description = "Legally vetted residential and commercial lease contract with rental advance clauses and utility reconciliations.",
            fileFormat = "DOCX",
            fileSize = "1.1 MB",
            pageCount = 8,
            downloadsCount = 112,
            samplePreviewText = "MEMORANDUM OF LEASE AGREEMENT made this day between LANDLORD and TENANT. Premises situated at Stand No..."
        ),
        DocumentItem(
            id = "doc-8",
            title = "Department of National Registration Official Guide (NRC & Passport)",
            category = "Government Forms",
            price = 0.0,
            tierLabel = "Free",
            description = "Requirements, affidavit templates, and police report guides for replacing lost NRCs and applying for e-Passports.",
            fileFormat = "PDF",
            fileSize = "1.5 MB",
            pageCount = 12,
            downloadsCount = 654,
            samplePreviewText = "Ministry of Home Affairs & Internal Security: Department of National Registration and Passports..."
        )
    )

    // Membership Plans
    val membershipPlans = listOf(
        MembershipPlan(
            id = MembershipTier.FREE,
            name = "Free Membership",
            monthlyPrice = 0.0,
            yearlyPrice = 0.0,
            tagline = "Essential forms and public guidance",
            features = listOf(
                "Access to free government documents",
                "2 complimentary document downloads / month",
                "Standard cafe rates",
                "AdMob in-app advertisements"
            ),
            adPolicy = "Standard AdMob Banners & Interstitials",
            serviceDiscountPercent = 0,
            freeDownloadsNote = "2 / month"
        ),
        MembershipPlan(
            id = MembershipTier.STANDARD,
            name = "Standard Membership",
            monthlyPrice = 45.0,
            yearlyPrice = 450.0,
            tagline = "Popular for students and regular job seekers",
            features = listOf(
                "Unlimited access to K2 & K5 exam documents",
                "50% discount on K10 & K20 legal templates",
                "15% discount on all cafe printing & typing",
                "Zero interstitial popup advertisements",
                "Free high-speed cafe Wi-Fi voucher"
            ),
            adPolicy = "Reduced Ads (No Interstitials)",
            serviceDiscountPercent = 15,
            freeDownloadsNote = "10 / month"
        ),
        MembershipPlan(
            id = MembershipTier.PREMIUM,
            name = "Premium VIP Membership",
            monthlyPrice = 95.0,
            yearlyPrice = 950.0,
            tagline = "Unlimited access for business owners and scholars",
            features = listOf(
                "100% Free downloads on ALL documents",
                "Completely AD-FREE experience (zero AdMob)",
                "30% discount on typing, formatting & printing",
                "10% discount on all shop tech accessories",
                "Priority WhatsApp document filing support"
            ),
            adPolicy = "Zero Ads (100% Ad-Free)",
            serviceDiscountPercent = 30,
            freeDownloadsNote = "Unlimited"
        )
    )

    // Digital Bureau Cafe Services
    val services = mutableStateListOf(
        CafeService("srv-1", "Online Applications (ECZ / TEVETA / E-Gov)", "Applications", 35.0, "per application", "Official online submission for exam entries, teacher postings, and PACRA.", "20 - 45 mins"),
        CafeService("srv-2", "Executive CV Writing & ATS Optimization", "Writing & Formatting", 50.0, "per CV", "Tailored modern CV and cover letter drafting for Zambian job openings.", "2 - 4 hours"),
        CafeService("srv-3", "Fast Professional Typing Services", "Writing & Formatting", 10.0, "per page", "High-speed typing from handwritten manuscripts or voice audio into Word/PDF.", "15 mins / 5 pgs"),
        CafeService("srv-4", "Document Formatting & Thesis Binding Prep", "Writing & Formatting", 25.0, "per doc", "TOC generation, Harvard/APA reference citations, and thesis margins.", "1 - 2 hours"),
        CafeService("srv-5", "High-Speed B&W Laser Printing", "Printing & Copying", 2.0, "per page", "Crisp 1200 DPI monochrome laser print on premium 80gsm A4 paper.", "Instant"),
        CafeService("srv-6", "Vibrant Full-Color Digital Printing", "Printing & Copying", 5.0, "per page", "Rich digital color prints for proposals, certificates, and diagrams.", "Instant"),
        CafeService("srv-7", "Digital Passport Photo Sizing & Retouch", "Identity & Photos", 25.0, "set of 4 + digital", "ICAO compliant passport photos formatted for NRC, Visa and Passports.", "10 mins"),
        CafeService("srv-8", "High-Res Document Scanning & OCR to PDF", "Scanning & Archiving", 3.0, "per page", "Clear color/greyscale scanning compiled to searchable PDF.", "Instant")
    )

    val serviceOrders = mutableStateListOf<ServiceOrder>()

    // Online Tech Shop Products
    val products = mutableStateListOf(
        ShopProduct("prod-1", "SanDisk Cruzer Blade 32GB USB Flash Drive", "Storage", 85.0, 55.0, 18, 5, "Compact plug-and-play USB storage drive for assignments and past papers.", 42),
        ShopProduct("prod-2", "Kingston DataTraveler Exodia 64GB USB 3.2", "Storage", 135.0, 90.0, 12, 4, "High-speed USB 3.2 storage for heavy PDF libraries and course software.", 28),
        ShopProduct("prod-3", "Dual Type-C & Micro-USB OTG Mobile Adapter", "Accessories", 35.0, 18.0, 24, 6, "Connect any flash drive directly to your Android phone for fast file printing.", 65),
        ShopProduct("prod-4", "Ergonomic 2.4GHz Wireless Optical Mouse", "Accessories", 95.0, 60.0, 9, 3, "Silent-click wireless mouse with USB nano receiver, battery included.", 19),
        ShopProduct("prod-5", "Premium 3.5mm Stereo Earphones with Mic", "Audio", 45.0, 22.0, 15, 5, "Crisp audio for online interviews and TEVETA video tutorials.", 37),
        ShopProduct("prod-6", "Rotatrim Premium A4 Paper Ream (500 Sheets)", "Stationery", 110.0, 82.0, 32, 10, "Bright white 80gsm copy paper for bulk office printing and dissertations.", 54)
    )

    // Local Sponsored Advertisers
    val sponsoredAds = mutableStateListOf(
        SponsoredAd("ad-1", "Apex Polytechnic & Driving Academy", "Education", "+260 977 452 110", "+260977452110", "Enroll Now: TEVETA Certified Diplomas & Class B Driving", "Flexible evening and weekend classes in Lusaka. Fast-track your commercial driving license!", 250.0, "2026-11-01", "2026-12-01", 1420, 184, "active"),
        SponsoredAd("ad-2", "Copperbelt Tech & Smartphone Fix Lusaka Branch", "Repairs", "+260 966 892 344", "+260966892344", "Fast Screen & Battery Replacements (Same-Day)", "Located directly opposite Chileleko Cafe! 10% discount for cafe members.", 200.0, "2026-10-15", "2026-11-15", 980, 95, "active"),
        SponsoredAd("ad-3", "Mwila & Partners Legal Documentation Specialists", "Legal", "+260 955 120 908", "+260955120908", "PACRA Company Secretarial & Commissioner for Oaths", "Affidavits signed within 15 minutes, certified true copies, and commercial dispute arbitration.", 300.0, "2026-11-05", "2026-12-05", 710, 68, "active")
    )

    // Admin Users Directory
    val adminUsers = mutableStateListOf(
        AdminUser("admin-1", "Jaro Kabaso", "kabasojaro7734@gmail.com", "+260 977 452 110", "super_admin", "2026", "Chileleko Lusaka Main Hub (Cairo Road)", true, "2026-11-01", "2026-11-07 13:30"),
        AdminUser("admin-2", "Chileshe Mwape", "chileshe.m@chilelekocafe.zm", "+260 966 220 891", "branch_manager", "5678", "Chileleko Lusaka Main Hub (Cairo Road)", true, "2026-11-03", "2026-11-07 11:15"),
        AdminUser("admin-3", "Miriam Tembo", "miriam.cashier@chilelekocafe.zm", "+260 955 881 304", "cashier", "1234", "Front Counter Cashier Station", true, "2026-11-04", "2026-11-07 12:45")
    )
    val currentAdmin = mutableStateOf<AdminUser?>(adminUsers[0])
    val isAdminAuthenticated = mutableStateOf(true)

    // Referral Program
    val referralRule = mutableStateOf(ReferralRule(5.0, 3.0, 10.0, 25))
    val userReferralCode = "CHILELEKO-LUSAKA-77"
    val referralRecords = mutableStateListOf(
        ReferralRecord("ref-1", userReferralCode, "+260 977 821 004", "Chanda Bwalya", "credited", 50.0, 5.0, "2026-11-05 14:22"),
        ReferralRecord("ref-2", userReferralCode, "+260 966 312 908", "Mwamba Kasonde", "qualified", 20.0, 5.0, "2026-11-06 09:15"),
        ReferralRecord("ref-3", userReferralCode, "+260 955 771 229", "Mutale Phiri", "pending", 5.0, 0.0, "2026-11-07 08:30")
    )

    // Transactions Ledger
    val transactions = mutableStateListOf(
        Transaction("tx-101", "document_sale", "Downloaded: ECZ Grade 12 Mathematics Past Papers", 5.0, 0.0, 5.0, "mtn_momo", "MTN-ZM-77291", "verified", "2026-11-07 10:14", "097XXXX124"),
        Transaction("tx-102", "service_charge", "Service: Executive CV Writing & ATS Optimization", 50.0, 0.0, 50.0, "airtel_money", "AIR-ZM-44910", "verified", "2026-11-07 09:32", "096XXXX882"),
        Transaction("tx-103", "shop_sale", "Retail Shop: SanDisk Cruzer Blade 32GB Flash Drive", 85.0, 55.0, 30.0, "cafe_cash", "CLK-CSH-0914", "verified", "2026-11-07 08:45", "Walk-in Desk"),
        Transaction("tx-104", "membership_sub", "Membership: Standard Monthly Plan (30 Days)", 45.0, 0.0, 45.0, "mtn_momo", "MTN-ZM-88319", "verified", "2026-11-06 16:20", "097XXXX901"),
        Transaction("tx-105", "sponsored_ad", "Sponsored Ad Fee: Apex Polytechnic (November 2026)", 250.0, 0.0, 250.0, "airtel_money", "AIR-ZM-91044", "verified", "2026-11-01 11:00", "097XXXX110")
    )

    // AdMob State
    val isAdMobLive = mutableStateOf(false)
    val adMobImpressions = mutableStateOf(1280)
    val adMobClicks = mutableStateOf(86)
    val adMobEstimatedEarnings = mutableStateOf(23.68)

    // Financial Calculation Helpers
    fun calculateTotalGrossRevenue(): Double {
        return transactions.filter { it.status == "verified" }.sumOf { it.grossAmount } + adMobEstimatedEarnings.value
    }

    fun calculateTotalNetProfit(): Double {
        val verifiedNet = transactions.filter { it.status == "verified" }.sumOf { it.netProfit }
        return verifiedNet + adMobEstimatedEarnings.value
    }

    fun calculateShopNetProfit(): Double {
        return transactions.filter { it.type == "shop_sale" && it.status == "verified" }.sumOf { it.netProfit }
    }

    // Actions
    fun purchaseDocument(docId: String, method: String, phone: String = "097XXXXXXX"): String {
        val doc = documents.find { it.id == docId } ?: return ""
        val ref = when (method) {
            "mtn_momo" -> "MTN-ZM-${Random.nextInt(10000, 99999)}"
            "airtel_money" -> "AIR-ZM-${Random.nextInt(10000, 99999)}"
            else -> "CLK-CSH-${Random.nextInt(1000, 9999)}"
        }

        if (doc.price > 0 && method != "reward_token" && method != "membership_free") {
            val now = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
            transactions.add(0, Transaction(
                id = "tx-${System.currentTimeMillis()}",
                type = "document_sale",
                title = "Downloaded: ${doc.title}",
                grossAmount = doc.price,
                costAmount = 0.0,
                netProfit = doc.price,
                paymentMethod = method,
                reference = ref,
                status = "pending",
                timestamp = now,
                customerPhone = phone
            ))
        }
        return ref
    }

    fun addAdministrator(name: String, email: String, phone: String, role: String, pin: String, branch: String): Boolean {
        if (name.isBlank() || pin.length < 4) return false
        val newAdmin = AdminUser(
            id = "admin-${System.currentTimeMillis()}",
            fullName = name.trim(),
            email = email.ifBlank { "${name.lowercase().replace(" ", ".")}@chilelekocafe.zm" },
            phone = phone.trim(),
            role = role,
            pin = pin,
            branchLocation = branch.ifBlank { "Chileleko Main Branch" },
            active = true,
            createdAt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()),
            lastLoginAt = "Never"
        )
        adminUsers.add(newAdmin)
        return true
    }

    fun deleteAdministrator(adminId: String): Boolean {
        val target = adminUsers.find { it.id == adminId } ?: return false
        if (target.role == "super_admin" && adminUsers.count { it.role == "super_admin" } <= 1) {
            return false // Cannot delete only super admin
        }
        adminUsers.remove(target)
        return true
    }
}
