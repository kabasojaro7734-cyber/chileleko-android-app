package com.chileleko.internetcafe

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chileleko.internetcafe.data.CafeRepository
import com.chileleko.internetcafe.model.MembershipTier
import com.chileleko.internetcafe.ui.components.AdMobBannerComposable
import com.chileleko.internetcafe.ui.screens.*
import com.chileleko.internetcafe.ui.theme.*
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

enum class ScreenNav(val id: String, val label: String, val icon: ImageVector) {
    DOCUMENTS("documents", "Documents", Icons.Default.List),
    SERVICES("services", "Services", Icons.Default.Build),
    MEMBERSHIP("membership", "Memberships", Icons.Default.Star),
    SHOP("shop", "Tech Shop", Icons.Default.ShoppingCart),
    REFERRALS("referrals", "Referrals", Icons.Default.Share),
    SPONSORS("sponsors", "Sponsors", Icons.Default.ThumbUp),
    ADMIN("admin", "Admin Console", Icons.Default.Lock)
}

class MainActivity : ComponentActivity() {

    private var rewardedAd: RewardedAd? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Google Mobile Ads SDK
        MobileAds.initialize(this) {}
        loadRewardedAd()

        setContent {
            ChilelekoTheme {
                MainAppScaffold(
                    onTriggerRewardedAd = {
                        showRewardedAd()
                    }
                )
            }
        }
    }

    private fun loadRewardedAd() {
        val adRequest = AdRequest.Builder().build()
        // AdMob Test Rewarded Ad Unit ID
        RewardedAd.load(
            this,
            "ca-app-pub-3940256099942544/5224354917",
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    rewardedAd = null
                }
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }
            }
        )
    }

    private fun showRewardedAd() {
        if (rewardedAd != null) {
            rewardedAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewardedAd()
                }
                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    rewardedAd = null
                    loadRewardedAd()
                }
            }
            rewardedAd?.show(this) { rewardItem ->
                CafeRepository.userRewardTokens.value += 1
                Toast.makeText(
                    this,
                    "Reward granted: +1 Free Download Token! Total: ${CafeRepository.userRewardTokens.value}",
                    Toast.LENGTH_LONG
                ).show()
            }
        } else {
            // Simulated fallback reward for development testing
            CafeRepository.userRewardTokens.value += 1
            Toast.makeText(
                this,
                "AdMob Test Ad Finished: +1 Free Download Token granted! Total: ${CafeRepository.userRewardTokens.value}",
                Toast.LENGTH_SHORT
            ).show()
            loadRewardedAd()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(
    onTriggerRewardedAd: () -> Unit
) {
    var currentScreen by remember { mutableStateOf(ScreenNav.DOCUMENTS) }
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    val currentTier = CafeRepository.currentMembership.value
    val rewardTokens = CafeRepository.userRewardTokens.value

    Row(modifier = Modifier.fillMaxSize().background(Slate950)) {
        // Adaptive Navigation Rail for Tablets
        if (isTablet) {
            NavigationRail(
                containerColor = Slate900,
                contentColor = Slate100,
                header = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(vertical = 12.dp)
                    ) {
                        Surface(
                            color = Amber400,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("C", fontWeight = FontWeight.Bold, color = Slate950, fontSize = 20.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "CHILELEKO",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Amber400
                        )
                    }
                }
            ) {
                ScreenNav.values().forEach { screen ->
                    val selected = currentScreen == screen
                    NavigationRailItem(
                        selected = selected,
                        onClick = { currentScreen = screen },
                        icon = { Icon(screen.icon, contentDescription = screen.label) },
                        label = { Text(screen.label, fontSize = 10.sp) },
                        colors = NavigationRailItemDefaults.colors(
                            selectedIconColor = Slate950,
                            selectedTextColor = Amber400,
                            indicatorColor = Amber400,
                            unselectedIconColor = Slate400,
                            unselectedTextColor = Slate400
                        )
                    )
                }
            }
        }

        // Main Viewport
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = "CHILELEKO INTERNET CAFE",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Slate100
                            )
                            Text(
                                text = "Lusaka, Zambia · Continuous Monetization",
                                fontSize = 10.sp,
                                color = Slate400
                            )
                        }
                    },
                    actions = {
                        // Rewarded Ad Token trigger
                        Surface(
                            color = Slate850,
                            shape = RoundedCornerShape(16.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Slate700),
                            modifier = Modifier.padding(end = 6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Tokens: $rewardTokens",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Amber400
                                )
                            }
                        }

                        // Membership Tier Badge
                        Surface(
                            color = if (currentTier == MembershipTier.PREMIUM) Amber950 else Slate850,
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (currentTier == MembershipTier.PREMIUM) Amber500 else Slate700
                            ),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text(
                                text = currentTier.label.uppercase(),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (currentTier == MembershipTier.PREMIUM) Amber300 else Slate300
                            )
                        }

                        // Quick Admin Console switch button
                        IconButton(
                            onClick = {
                                currentScreen = if (currentScreen == ScreenNav.ADMIN) ScreenNav.DOCUMENTS else ScreenNav.ADMIN
                            }
                        ) {
                            Icon(
                                imageVector = if (currentScreen == ScreenNav.ADMIN) Icons.Default.Close else Icons.Default.Lock,
                                contentDescription = "Admin Switch",
                                tint = if (currentScreen == ScreenNav.ADMIN) Amber400 else Slate400
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Slate900,
                        titleContentColor = Slate100
                    )
                )
            },
            bottomBar = {
                Column {
                    // Google AdMob Banner Composable (suppressed for VIP members)
                    if (currentScreen != ScreenNav.ADMIN) {
                        AdMobBannerComposable()
                    }

                    // Bottom Navigation Bar for Mobile Phones
                    if (!isTablet) {
                        NavigationBar(
                            containerColor = Slate900,
                            contentColor = Slate100,
                            tonalElevation = 8.dp
                        ) {
                            val phoneNavItems = listOf(
                                ScreenNav.DOCUMENTS,
                                ScreenNav.SERVICES,
                                ScreenNav.MEMBERSHIP,
                                ScreenNav.SHOP,
                                ScreenNav.REFERRALS
                            )

                            phoneNavItems.forEach { screen ->
                                val isSelected = currentScreen == screen
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { currentScreen = screen },
                                    icon = { Icon(screen.icon, contentDescription = screen.label, modifier = Modifier.size(18.dp)) },
                                    label = { Text(screen.label, fontSize = 9.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Slate950,
                                        selectedTextColor = Amber400,
                                        indicatorColor = Amber400,
                                        unselectedIconColor = Slate400,
                                        unselectedTextColor = Slate400
                                    )
                                )
                            }
                        }
                    }
                }
            },
            containerColor = Slate950
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (currentScreen) {
                    ScreenNav.DOCUMENTS -> DocumentMarketplaceScreen(onTriggerRewardedAd = onTriggerRewardedAd)
                    ScreenNav.SERVICES -> CafeServicesScreen()
                    ScreenNav.MEMBERSHIP -> MembershipScreen()
                    ScreenNav.SHOP -> ShopScreen()
                    ScreenNav.REFERRALS -> ReferralsScreen()
                    ScreenNav.SPONSORS -> SponsoredAdsScreen()
                    ScreenNav.ADMIN -> AdminConsoleScreen()
                }
            }
        }
    }
}
