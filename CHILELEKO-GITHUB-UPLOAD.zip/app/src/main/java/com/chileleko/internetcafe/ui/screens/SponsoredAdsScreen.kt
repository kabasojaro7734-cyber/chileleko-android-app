package com.chileleko.internetcafe.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chileleko.internetcafe.data.CafeRepository
import com.chileleko.internetcafe.model.SponsoredAd
import com.chileleko.internetcafe.ui.theme.*

@Composable
fun SponsoredAdsScreen() {
    val context = LocalContext.current
    val ads = CafeRepository.sponsoredAds
    var showInquiryDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Showcase Header
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, Slate800, RoundedCornerShape(12.dp)),
            color = Slate900
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Featured Lusaka Businesses",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Slate100
                        )
                        Text(
                            text = "Verified commercial partners supporting Chileleko Internet Cafe",
                            fontSize = 11.sp,
                            color = Slate400
                        )
                    }

                    Button(
                        onClick = { showInquiryDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = Slate950),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("Advertise Here", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(ads) { ad ->
                SponsoredAdCard(
                    ad = ad,
                    onCall = {
                        ad.clicksCount += 1
                        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${ad.contactPhone.replace(" ", "")}"))
                        context.startActivity(dialIntent)
                    },
                    onWhatsApp = {
                        ad.clicksCount += 1
                        val cleanNum = ad.whatsappNumber.replace("+", "").replace(" ", "")
                        val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=$cleanNum&text=Hello%20${ad.businessName},%20I%20saw%20your%20business%20featured%20on%20the%20Chileleko%20Internet%20Cafe%20Android%20app."))
                        context.startActivity(waIntent)
                    }
                )
            }
        }
    }

    if (showInquiryDialog) {
        AlertDialog(
            onDismissRequest = { showInquiryDialog = false },
            title = {
                Text("Promote Your Business on Chileleko Cafe", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Slate100)
            },
            text = {
                Column {
                    Text(
                        text = "Connect directly with thousands of tertiary students, exam candidates, PACRA entrepreneurs, and job seekers across Lusaka every single week.",
                        fontSize = 12.sp,
                        color = Slate300
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(color = Slate850, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Standard In-App Banner: K200 / month", fontSize = 12.sp, color = Amber400, fontWeight = FontWeight.Bold)
                            Text("Featured Sponsor Spotlight: K300 / month", fontSize = 12.sp, color = Amber300, fontWeight = FontWeight.Bold)
                            Text("Includes real-time impression & click analytics", fontSize = 10.sp, color = Slate400)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showInquiryDialog = false
                        val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:+260977452110"))
                        context.startActivity(dialIntent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = Slate950)
                ) {
                    Text("Call Cafe Admin (+260 977 452 110)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { showInquiryDialog = false }) {
                    Text("Close", color = Slate400)
                }
            },
            containerColor = Slate900,
            shape = RoundedCornerShape(12.dp)
        )
    }
}

@Composable
fun SponsoredAdCard(
    ad: SponsoredAd,
    onCall: () -> Unit,
    onWhatsApp: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, Slate800, RoundedCornerShape(12.dp)),
        color = Slate900
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = Slate800,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "LOCAL SPONSOR · ${ad.category.uppercase()}",
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber400,
                        letterSpacing = 0.5.sp
                    )
                }

                Text(
                    text = "${ad.impressionsCount} views · ${ad.clicksCount} inquiries",
                    fontSize = 10.sp,
                    color = Slate400
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = ad.headline,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Slate100
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = ad.businessName,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Amber300
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = ad.tagline,
                fontSize = 12.sp,
                color = Slate300
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onCall,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Slate100),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Slate700),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(14.dp), tint = Amber400)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Call Now", fontSize = 12.sp)
                }

                Button(
                    onClick = onWhatsApp,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Emerald500, contentColor = Slate950),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 6.dp)
                ) {
                    Text("WhatsApp", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
