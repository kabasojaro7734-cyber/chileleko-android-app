package com.chileleko.internetcafe.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chileleko.internetcafe.data.CafeRepository
import com.chileleko.internetcafe.model.CafeService
import com.chileleko.internetcafe.model.MembershipTier
import com.chileleko.internetcafe.ui.components.PaymentBottomSheet
import com.chileleko.internetcafe.ui.theme.*

@Composable
fun CafeServicesScreen() {
    val services = CafeRepository.services
    val currentTier = CafeRepository.currentMembership.value

    var selectedService by remember { mutableStateOf<CafeService?>(null) }
    var serviceQuantity by remember { mutableIntStateOf(1) }
    var customerNotes by remember { mutableStateOf("") }
    var bookingSuccessAlert by remember { mutableStateOf<String?>(null) }

    val discountPercent = when (currentTier) {
        MembershipTier.PREMIUM -> 30
        MembershipTier.STANDARD -> 15
        else -> 0
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
    ) {
        // Top banner: Membership discount benefit
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            color = Slate900,
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = Amber400, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Chileleko Digital Bureau Services",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate100
                    )
                    Text(
                        text = if (discountPercent > 0)
                            "Your ${currentTier.label} membership unlocks ${discountPercent}% automatic discount on all bureau charges."
                        else
                            "Upgrade to Standard (15% off) or Premium (30% off) to save on all typing and printing services.",
                        fontSize = 11.sp,
                        color = if (discountPercent > 0) Amber300 else Slate400
                    )
                }
            }
        }

        // Service Catalog List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(services) { srv ->
                val basePrice = srv.price
                val discountedPrice = if (discountPercent > 0) basePrice * (1.0 - discountPercent / 100.0) else basePrice

                ServiceItemCard(
                    service = srv,
                    basePrice = basePrice,
                    discountedPrice = discountedPrice,
                    discountPercent = discountPercent,
                    onBook = {
                        selectedService = srv
                        serviceQuantity = 1
                    }
                )
            }
        }
    }

    // Booking & Payment Bottom Sheet
    if (selectedService != null) {
        val srv = selectedService!!
        val unitPrice = if (discountPercent > 0) srv.price * (1.0 - discountPercent / 100.0) else srv.price
        val totalAmount = unitPrice * serviceQuantity

        PaymentBottomSheet(
            title = "Order: ${srv.name} (x$serviceQuantity)",
            amountZMW = totalAmount,
            itemType = "service_charge",
            itemId = srv.id,
            onDismiss = { selectedService = null },
            onSuccess = { ref ->
                selectedService = null
                bookingSuccessAlert = "Service order booked successfully! (Ref: $ref). Bring your materials or WhatsApp our digital desk (+260 977 452 110)."
            }
        )
    }

    if (bookingSuccessAlert != null) {
        Snackbar(
            modifier = Modifier.padding(16.dp),
            action = {
                TextButton(onClick = { bookingSuccessAlert = null }) {
                    Text("OK", color = Amber400)
                }
            },
            containerColor = Slate900,
            contentColor = Slate100
        ) {
            Text(bookingSuccessAlert!!, fontSize = 12.sp)
        }
    }
}

@Composable
fun ServiceItemCard(
    service: CafeService,
    basePrice: Double,
    discountedPrice: Double,
    discountPercent: Int,
    onBook: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, Slate800, RoundedCornerShape(12.dp)),
        color = Slate900
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = Slate800,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = service.category.uppercase(),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber400
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (discountPercent > 0) {
                        Text(
                            text = "K${String.format("%.0f", basePrice)}",
                            fontSize = 11.sp,
                            color = Slate400,
                            modifier = Modifier.padding(end = 6.dp)
                        )
                    }
                    Text(
                        text = "K${String.format("%.0f", discountedPrice)}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Amber400
                    )
                    Text(
                        text = " / ${service.unitLabel}",
                        fontSize = 11.sp,
                        color = Slate400
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = service.name,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Slate100
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = service.description,
                fontSize = 12.sp,
                color = Slate300
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Est. Turnaround: ${service.turnaroundTime}",
                    fontSize = 11.sp,
                    color = Slate400
                )

                Button(
                    onClick = onBook,
                    colors = ButtonDefaults.buttonColors(containerColor = Amber400, contentColor = Slate950),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text("Order Service", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
