package com.chileleko.internetcafe.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chileleko.internetcafe.data.CafeRepository
import com.chileleko.internetcafe.model.BillingCycle
import com.chileleko.internetcafe.model.MembershipPlan
import com.chileleko.internetcafe.model.MembershipTier
import com.chileleko.internetcafe.ui.components.PaymentBottomSheet
import com.chileleko.internetcafe.ui.theme.*

@Composable
fun MembershipScreen() {
    val plans = CafeRepository.membershipPlans
    val currentTier = CafeRepository.currentMembership.value
    var isYearly by remember { mutableStateOf(false) }
    var selectedPlanToBuy by remember { mutableStateOf<MembershipPlan?>(null) }
    var upgradeSuccessAlert by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate950)
    ) {
        // Billing Cycle Toggle (Monthly vs Yearly)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Choose Your Chileleko Pass",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Slate100
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Unlock ad-free access, free downloads and discounts across Lusaka",
                fontSize = 12.sp,
                color = Slate400,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            Surface(
                color = Slate900,
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Slate800)
            ) {
                Row(
                    modifier = Modifier.padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = !isYearly,
                        onClick = { isYearly = false },
                        label = { Text("Monthly Billing", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Amber400,
                            selectedLabelColor = Slate950,
                            containerColor = Slate900,
                            labelColor = Slate300
                        ),
                        border = null
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    FilterChip(
                        selected = isYearly,
                        onClick = { isYearly = true },
                        label = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Annual Billing", fontSize = 12.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Surface(color = Emerald950, shape = RoundedCornerShape(4.dp)) {
                                    Text("Save 17%", color = Emerald400, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                }
                            }
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Amber400,
                            selectedLabelColor = Slate950,
                            containerColor = Slate900,
                            labelColor = Slate300
                        ),
                        border = null
                    )
                }
            }
        }

        // Plans List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(plans) { plan ->
                val price = if (isYearly) plan.yearlyPrice else plan.monthlyPrice
                val isCurrent = currentTier == plan.id

                MembershipPlanCard(
                    plan = plan,
                    priceZMW = price,
                    isYearly = isYearly,
                    isCurrent = isCurrent,
                    onSelect = {
                        if (plan.id == MembershipTier.FREE) {
                            CafeRepository.currentMembership.value = MembershipTier.FREE
                            upgradeSuccessAlert = "Switched to Free Membership."
                        } else {
                            selectedPlanToBuy = plan
                        }
                    }
                )
            }
        }
    }

    if (selectedPlanToBuy != null) {
        val plan = selectedPlanToBuy!!
        val price = if (isYearly) plan.yearlyPrice else plan.monthlyPrice

        PaymentBottomSheet(
            title = "Subscription: ${plan.name} (${if (isYearly) "1 Year" else "1 Month"})",
            amountZMW = price,
            itemType = "membership_sub",
            itemId = plan.id.name,
            onDismiss = { selectedPlanToBuy = null },
            onSuccess = { ref ->
                selectedPlanToBuy = null
                CafeRepository.currentMembership.value = plan.id
                upgradeSuccessAlert = "Congratulations! You are now on ${plan.name} (Ref: $ref). All benefits and ad policies active."
            }
        )
    }

    if (upgradeSuccessAlert != null) {
        Snackbar(
            modifier = Modifier.padding(16.dp),
            action = {
                TextButton(onClick = { upgradeSuccessAlert = null }) {
                    Text("OK", color = Amber400)
                }
            },
            containerColor = Slate900,
            contentColor = Slate100
        ) {
            Text(upgradeSuccessAlert!!, fontSize = 12.sp)
        }
    }
}

@Composable
fun MembershipPlanCard(
    plan: MembershipPlan,
    priceZMW: Double,
    isYearly: Boolean,
    isCurrent: Boolean,
    onSelect: () -> Unit
) {
    val isPremium = plan.id == MembershipTier.PREMIUM

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(
                width = if (isCurrent) 2.dp else if (isPremium) 1.5.dp else 1.dp,
                color = if (isCurrent) Emerald500 else if (isPremium) Amber400 else Slate800,
                shape = RoundedCornerShape(14.dp)
            ),
        color = if (isPremium) Slate900 else Slate900.copy(alpha = 0.8f)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = plan.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Slate100
                    )
                    if (isPremium) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(Icons.Default.Star, contentDescription = null, tint = Amber400, modifier = Modifier.size(16.dp))
                    }
                }

                if (isCurrent) {
                    Surface(
                        color = Emerald950,
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Emerald500)
                    ) {
                        Text(
                            text = "CURRENT PLAN",
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Emerald400
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = plan.tagline,
                fontSize = 12.sp,
                color = Slate400
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Price Row
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = if (priceZMW == 0.0) "Free" else "K${String.format("%.0f", priceZMW)}",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isPremium) Amber400 else Slate100
                )
                if (priceZMW > 0.0) {
                    Text(
                        text = if (isYearly) " / year" else " / month",
                        fontSize = 12.sp,
                        color = Slate400,
                        modifier = Modifier.padding(bottom = 3.dp, start = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Ad policy tag
            Surface(
                color = Slate850,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Ad Policy: ", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate300)
                    Text(plan.adPolicy, fontSize = 11.sp, color = if (isPremium) Emerald400 else Amber400)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Features list
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                plan.features.forEach { feat ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = if (isPremium) Amber400 else Emerald400,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = feat,
                            fontSize = 12.sp,
                            color = Slate300
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onSelect,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isCurrent) Slate800 else if (isPremium) Amber400 else Slate700,
                    contentColor = if (isCurrent) Slate400 else if (isPremium) Slate950 else Slate100
                ),
                shape = RoundedCornerShape(8.dp),
                enabled = !isCurrent
            ) {
                Text(
                    text = if (isCurrent) "Active Subscription" else if (plan.id == MembershipTier.FREE) "Downgrade to Free" else "Upgrade to ${plan.name}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}
